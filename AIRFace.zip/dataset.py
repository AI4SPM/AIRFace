import os
from PIL import Image
from torch.utils import data
from torchvision.transforms import InterpolationMode

import config as c
import torchvision.transforms as transforms
import random


def load_image_mask(img_path, mask_path):
    img = Image.open(img_path).convert("RGB")
    mask = Image.open(mask_path).convert("L")

    img = transforms.Resize(
        (c.resize_w, c.resize_h),
        interpolation=InterpolationMode.BILINEAR
    )(img)
    img = transforms.ToTensor()(img)

    mask = transforms.Resize(
        (c.resize_w, c.resize_h),
        interpolation=InterpolationMode.NEAREST
    )(mask)
    mask = transforms.ToTensor()(mask)

    mask = (mask > 0.5).float()
    return img, mask


class VGGFace2MaskDataset(data.Dataset):
    def __init__(self, data_path):
        self.img_root = os.path.join(data_path, 'img')
        self.mask_root = os.path.join(data_path, 'mask')

        self.img_paths = []
        self.names = []

        for person_id in os.listdir(self.img_root):
            person_dir = os.path.join(self.img_root, person_id)
            if not os.path.isdir(person_dir):
                continue

            for img_name in os.listdir(person_dir):
                if img_name.lower().endswith(('jpg', 'jpeg', 'png')):
                    name = f"{person_id}/{img_name}"
                    self.names.append(name)
                    self.img_paths.append(os.path.join(person_dir, img_name))

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):

        name = self.names[idx]

        img_path = self.img_paths[idx]
        mask_path = os.path.join(self.mask_root, name)

        img, mask = load_image_mask(img_path, mask_path)

        return img, mask, name


netHR_train_dataset = VGGFace2MaskDataset(data_path=c.train_data_path)
netHR_train_loader = data.DataLoader(
    netHR_train_dataset,
    batch_size=8,
    shuffle=True,
    pin_memory=True,
    num_workers=1,
    drop_last=True
)

netHR_test_dataset = VGGFace2MaskDataset(data_path=c.test_data_path)
netHR_test_loader = data.DataLoader(
    netHR_test_dataset,
    batch_size=8,
    shuffle=True,
    pin_memory=True,
    drop_last=True
)


class VGGFace2TripletDataset(data.Dataset):
    def __init__(self, data_path):
        self.img_root = os.path.join(data_path, 'img')
        self.mask_root = os.path.join(data_path, 'mask')

        self.samples = []
        self.person_dict = {}

        for person_id in os.listdir(self.img_root):
            person_dir = os.path.join(self.img_root, person_id)
            if not os.path.isdir(person_dir):
                continue

            img_names = [f for f in os.listdir(person_dir) if f.lower().endswith(('jpg', 'jpeg', 'png'))]
            if len(img_names) < 2:
                continue

            self.person_dict[person_id] = []

            for img_name in img_names:
                img_path = os.path.join(person_dir, img_name)
                mask_path = os.path.join(self.mask_root, f"{person_id}/{img_name}")
                idx = len(self.samples)
                self.samples.append((person_id, img_name, img_path, mask_path))
                self.person_dict[person_id].append(idx)

        self.person_ids = list(self.person_dict.keys())

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        # --- Anchor ---
        person_id, img_name, img_path, mask_path = self.samples[idx]
        x_anchor, m_anchor = load_image_mask(img_path, mask_path)

        # --- Positive  ---
        pos_idx = idx
        while pos_idx == idx:
            pos_idx = random.choice(self.person_dict[person_id])
        _, _, pos_img_path, pos_mask_path = self.samples[pos_idx]
        x_pos, m_pos = load_image_mask(pos_img_path, pos_mask_path)

        # --- Negative  ---
        neg_person_id = person_id
        while neg_person_id == person_id:
            neg_person_id = random.choice(self.person_ids)
        neg_idx = random.choice(self.person_dict[neg_person_id])
        _, _, neg_img_path, neg_mask_path = self.samples[neg_idx]
        x_neg, m_neg = load_image_mask(neg_img_path, neg_mask_path)

        return x_anchor, m_anchor, x_pos, m_pos, x_neg, m_neg


triplet_train_dataset = VGGFace2TripletDataset(data_path=c.train_data_path)
triplet_train_loader = data.DataLoader(
    triplet_train_dataset,
    batch_size=8,
    shuffle=True,
    pin_memory=True,
    num_workers=1,
    drop_last=True
)

triplet_test_dataset = VGGFace2TripletDataset(data_path=c.test_data_path)
triplet_test_loader = data.DataLoader(
    triplet_test_dataset,
    batch_size=8,
    shuffle=True,
    pin_memory=True,
    num_workers=1,
    drop_last=True
)
