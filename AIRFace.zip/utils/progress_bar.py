class ProgressBar:
    def __init__(self):
        self.p = None

    def __call__(self, iterable):
        from tqdm import tqdm
        self.p = tqdm(
            iterable,
            ncols=138
        )
        return self.p

    def say(self, **kwargs):
        if self.p is not None:
            self.p.set_postfix(**kwargs)
