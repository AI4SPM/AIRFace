import torch
import torch.nn as nn
import torchvision.transforms.functional as TF
from torchvision.transforms import InterpolationMode


class MDSLayer(nn.Module):

    def __init__(
        self,
        threshold=0.1,
        max_rotate=1.0,
        scale_min=0.98,
        scale_max=1.02,
        max_shear=2.0,
        max_shift_ratio=0.02,
    ):
        super().__init__()

        self.threshold = threshold

        self.max_rotate = max_rotate

        self.scale_min = scale_min
        self.scale_max = scale_max

        self.max_shear = max_shear

        self.max_shift_ratio = max_shift_ratio


    def _sample_kernel1(self, device):

        kernels = torch.tensor(
            [3, 5, 7, 9],
            device=device
        )

        probs = torch.tensor(
            [0.7, 0.1, 0.1, 0.1],
            device=device
        )

        idx = torch.multinomial(
            probs,
            num_samples=1
        )

        return int(kernels[idx].item())


    def _sample_kernel2(self, device):

        kernels = torch.tensor(
            [1, 3, 5, 7, 9],
            device=device
        )

        probs = torch.tensor(
            [0.7, 0.075, 0.075, 0.075, 0.075],
            device=device
        )

        idx = torch.multinomial(
            probs,
            num_samples=1
        )

        return int(kernels[idx].item())


    def _gaussian_blur(self, x, kernel_size):

        if kernel_size == 1:
            return x

        return TF.gaussian_blur(
            x,
            kernel_size=[kernel_size, kernel_size],
            sigma=None
        )


    def forward(self, mask):


        B, C, H, W = mask.shape

        outputs = []

        for i in range(B):

            m = mask[i]

            # =====================================
            # 1. Random affine transform
            # =====================================

            angle = (
                torch.rand(1).item() * 2 - 1
            ) * self.max_rotate

            scale = (
                self.scale_min
                +
                torch.rand(1).item()
                * (self.scale_max - self.scale_min)
            )

            shear_x = (
                torch.rand(1).item() * 2 - 1
            ) * self.max_shear

            shear_y = (
                torch.rand(1).item() * 2 - 1
            ) * self.max_shear

            max_dx = W * self.max_shift_ratio
            max_dy = H * self.max_shift_ratio

            translate_x = int(
                round(
                    (torch.rand(1).item() * 2 - 1)
                    * max_dx
                )
            )

            translate_y = int(
                round(
                    (torch.rand(1).item() * 2 - 1)
                    * max_dy
                )
            )

            m = TF.affine(
                m,
                angle=angle,
                translate=[
                    translate_x,
                    translate_y
                ],
                scale=scale,
                shear=[
                    shear_x,
                    shear_y
                ],
                interpolation=InterpolationMode.BILINEAR,
                fill=0.0,
            )

            # =====================================
            # 2. Gaussian Blur 1
            # =====================================

            k1 = self._sample_kernel1(mask.device)

            m = self._gaussian_blur(
                m,
                k1
            )

            # =====================================
            # 3. Threshold / indicator
            #
            # paper:
            # I[G_sigma1(...) > 0.1]
            # =====================================

            m = (
                m > self.threshold
            ).float()

            # =====================================
            # 4. Gaussian Blur 2
            # =====================================

            k2 = self._sample_kernel2(mask.device)

            m = self._gaussian_blur(
                m,
                k2
            )

            m = torch.clamp(
                m,
                0.0,
                1.0
            )

            outputs.append(m)

        mask_mds = torch.stack(
            outputs,
            dim=0
        )

        return mask_mds