import os
import torch

device = torch.device('cuda:0')

root_dir = os.path.dirname(os.path.abspath(__file__))
pth_path = os.path.join(root_dir, 'pth')

resize_h = 224
resize_w = 224

train_data_path = '/root/dataset/vggface2_mask/train'
test_data_path = '/root/dataset/vggface2_mask/test'

simnet_pth = os.path.join(pth_path, 'jpegsim80k.pt')
netArc_path = os.path.join(pth_path, 'arcface_checkpoint.tar')
netG_path = os.path.join(pth_path, '90000_net_G.pth')
netHR_path = os.path.join(pth_path, 'model_checkpoint_160000.pth')
netFC_path = os.path.join(pth_path, 'netFC_90000.pth')


# ===========================================================================

def get_netG(gpu=device):
    from models.generator import Generator_Adain_Upsample
    netG = Generator_Adain_Upsample(input_nc=4, output_nc=3, latent_size=512, n_blocks=9).to(gpu)
    netG.load_state_dict(torch.load(netG_path))
    netG.eval()
    netG.requires_grad_(False)
    return netG


def get_netArc(gpu=device):
    netArc = torch.load(netArc_path, map_location=torch.device("cpu")).to(gpu)
    netArc.eval()
    netArc.requires_grad_(False)
    return netArc


def get_netHR(gpu=device):
    from models.hrnet import HRNET
    netPHR = HRNET().to(gpu)
    netPHR.load(netHR_path)
    netPHR.eval()
    netPHR.requires_grad_(False)
    return netPHR


def get_netFC(gpu=device):
    from models.feature_converter import FeatureConverter
    netFC = FeatureConverter().to(gpu)
    state_dict = torch.load(
        netFC_path,
        map_location=torch.device('cpu')
    )
    netFC.load_state_dict(state_dict)
    netFC.eval()
    netFC.requires_grad_(False)
    return netFC


# ===========================================================================

# ----- arcface
num_classes = 93431

# ----- netHR
noise = True
mds = True

epochs = 120
iterations = 160000
SAVE_itertaion_freq = 40000

# network
lr_g = 1e-4
weight_step = 40000
init_scale = 0.1
gamma = 0.6

# loss
bg_weight = 10
face_weight = 20
whole_reveal_weight = 10
id_weight = 10
