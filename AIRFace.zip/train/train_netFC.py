import torch
import torch.nn.functional as F

from dataset import triplet_train_loader
from models.feature_converter import FeatureConverter
import config as c
import torch.optim as optim
import lpips
import os

from utils.progress_bar import ProgressBar


def hid_face_to_bg(hider, x, m):
    with torch.no_grad():
        face = x * m
        bg = x * (1.0 - m)
        bg_hid = hider(m, bg, face, rev=False)
        return bg_hid


def lpips_chunked(lpips_loss, orig, anon, chunk_size=1):
    total = 0.0
    batch_size = orig.shape[0]

    for orig_i, anon_i in zip(orig.split(chunk_size, dim=0), anon.split(chunk_size, dim=0)):
        loss_i = lpips_loss(orig_i, anon_i).sum()
        total = total + loss_i

    return total / batch_size


if __name__ == '__main__':
    device = c.device

    train_loader = triplet_train_loader

    netArc = c.get_netArc()
    netG = c.get_netG()
    netHR = c.get_netHR()

    netFC = FeatureConverter().to(device)
    netFC.train()
    optim_FC = optim.Adam(netFC.parameters(), lr=0.0001, betas=(0.9, 0.999))

    lpips_loss = lpips.LPIPS(net='vgg', version='0.1').to(device)
    l2_loss = torch.nn.MSELoss().to(device)
    lpips_loss.eval()
    lpips_loss.requires_grad_(False)
    print('start train.........')
    progressBar = ProgressBar()
    step = 0
    for epoch in range(0, 10):
        for x_a, m_a, x_p, m_p, x_n, m_n in progressBar(train_loader):
            x_a, m_a = x_a.to(device), m_a.to(device)
            x_p, m_p = x_p.to(device), m_p.to(device)
            x_n, m_n = x_n.to(device), m_n.to(device)

            with torch.no_grad():
                a_id = F.normalize(netArc(F.interpolate(x_a, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)
                p_id = F.normalize(netArc(F.interpolate(x_p, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)
                n_id = F.normalize(netArc(F.interpolate(x_n, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)

            a_hid = hid_face_to_bg(netHR, x_a, m_a)
            p_hid = hid_face_to_bg(netHR, x_p, m_p)
            n_hid = hid_face_to_bg(netHR, x_n, m_n)

            a_z = netFC(a_id)
            p_z = netFC(p_id)
            n_z = netFC(n_id)

            a_anon_img = netG(a_hid, m_a, a_z)
            p_anon_img = netG(p_hid, m_p, p_z)
            n_anon_img = netG(n_hid, m_n, n_z)

            a_anon_id = F.normalize(netArc(F.interpolate(a_anon_img, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)
            p_anon_id = F.normalize(netArc(F.interpolate(p_anon_img, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)
            n_anon_id = F.normalize(netArc(F.interpolate(n_anon_img, (112, 112), mode='bicubic') * 2 - 1), p=2, dim=1)

            orig_id = torch.cat([a_id, p_id, n_id], dim=0)
            anon_id = torch.cat([a_anon_id, p_anon_id, n_anon_id], dim=0)

            loss_anon = F.relu(torch.cosine_similarity(orig_id, anon_id)).mean()

            sim_ap = torch.cosine_similarity(a_anon_id, p_anon_id)
            sim_an = torch.cosine_similarity(a_anon_id, n_anon_id)
            loss_tri = F.relu(sim_an - sim_ap + 0.5).mean()

            orig_img = torch.cat([x_a, x_p, x_n], dim=0).detach()
            anon_img = torch.cat([a_anon_img, p_anon_img, n_anon_img], dim=0)

            l1 = l2_loss(orig_img, anon_img)

            l2 = lpips_chunked(
                lpips_loss,
                orig_img * 2 - 1,
                anon_img * 2 - 1,
                chunk_size=1
            )

            loss_rec = 0.2 * l1 + 0.8 * l2

            total_loss = 5 * loss_anon + 10 * loss_tri + 5 * loss_rec

            optim_FC.zero_grad()
            total_loss.backward()
            optim_FC.step()

            progressBar.say(
                step=step + 1,
                total_loss=total_loss.item(),
                loss_anon=loss_anon.item(),
                loss_tri=loss_tri.item(),
                loss_rec=loss_rec.item(),
            )
            step += 1

            if step % 10000 == 0:
                torch.save(netFC.state_dict(), os.path.join(c.pth_path, 'netFC_0.5_%d.pth' % step))

            if step % 90000 == 0:
                print('train end...')
                torch.save(netFC.state_dict(), os.path.join(c.pth_path, 'netFC_0.5_final.pth'))
                exit()
