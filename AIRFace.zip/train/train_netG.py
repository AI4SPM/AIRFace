import os
import time
import argparse
import numpy as np

import torch
import torch.nn.functional as F
from torch.backends import cudnn

from models.hrnet import HRNET

from models.projected_model import fsModel
from dataset import triplet_train_loader
import config as c


def str2bool(v):
    return v.lower() in ('true')


class TrainOptions:
    def __init__(self):
        self.parser = argparse.ArgumentParser()
        self.initialized = False

    def initialize(self):
        self.parser.add_argument('--name', type=str, default='generator',
                                 help='name of the experiment. It decides where to store samples and models')
        self.parser.add_argument('--gpu_ids', default='0')
        self.parser.add_argument('--checkpoints_dir', type=str, default=c.pth_path, help='models are saved here')
        self.parser.add_argument('--isTrain', type=str2bool, default='True')

        # for training
        self.parser.add_argument('--continue_train', type=str2bool, default='True')
        self.parser.add_argument('--load_pretrain', type=str, default=c.pth_path + '/generator')
        self.parser.add_argument('--which_epoch', type=str, default='')

        self.parser.add_argument('--niter', type=int, default=10000, help='# of iter at starting learning rate')
        self.parser.add_argument('--niter_decay', type=int, default=10000,
                                 help='# of iter to linearly decay learning rate to zero')
        self.parser.add_argument('--beta1', type=float, default=0.0, help='momentum term of adam')
        self.parser.add_argument('--lr', type=float, default=0.0004, help='initial learning rate for adam')

        # for discriminators
        self.parser.add_argument('--lambda_feat', type=float, default=10.0, help='weight for feature matching loss')
        self.parser.add_argument('--lambda_id', type=float, default=30.0, help='weight for id loss')
        self.parser.add_argument('--lambda_rec', type=float, default=10.0, help='weight for reconstruction loss')

        self.parser.add_argument("--Arc_path", type=str, default=c.netArc_path, help="run ONNX model via TRT")
        self.parser.add_argument("--total_step", type=int, default=160000, help='total training step')
        self.parser.add_argument("--log_frep", type=int, default=200, help='frequence for printing log information')
        self.parser.add_argument("--model_freq", type=int, default=10000, help='frequence for saving the model')

        self.isTrain = True

    def parse(self, save=True):
        if not self.initialized:
            self.initialize()
        self.opt = self.parser.parse_args()
        self.opt.isTrain = self.isTrain  # train or test

        args = vars(self.opt)

        print('------------ Options -------------')
        for k, v in sorted(args.items()):
            print('%s: %s' % (str(k), str(v)))
        print('-------------- End ----------------')

        # save to the disk
        if self.opt.isTrain:
            expr_dir = os.path.join(self.opt.checkpoints_dir, self.opt.name)
            os.makedirs(expr_dir, exist_ok=True)

        return self.opt


def hid_face_to_bg(netHR, x, m):
    with torch.no_grad():
        face = x * m
        bg = x * (1.0 - m)
        bg_hid = netHR(m, bg, face, rev=False)
        return bg_hid


if __name__ == '__main__':

    opt = TrainOptions().parse()
    iter_path = os.path.join(opt.checkpoints_dir, opt.name, 'iter.txt')

    if opt.continue_train:
        try:
            start_epoch, epoch_iter = np.loadtxt(iter_path, delimiter=',', dtype=int)
        except:
            start_epoch, epoch_iter = 1, 0
        print('Resuming from epoch %d at iteration %d' % (start_epoch, epoch_iter))
    else:
        start_epoch, epoch_iter = 1, 0

    os.environ['CUDA_VISIBLE_DEVICES'] = str(opt.gpu_ids)
    print("GPU used : ", str(opt.gpu_ids))

    cudnn.benchmark = True

    netHR = HRNET()
    netHR.load(c.netHR_path)
    netHR = netHR.cuda()
    netHR.eval()
    netHR.requires_grad_(False)

    model = fsModel()
    model.initialize(opt)

    #####################################################

    log_name = os.path.join(opt.checkpoints_dir, opt.name, 'loss_log.txt')

    with open(log_name, "a") as log_file:
        now = time.strftime("%c")
        log_file.write('================ Training Loss (%s) ================\n' % now)

    optimizer_G, optimizer_D = model.optimizer_G, model.optimizer_D

    train_loader = triplet_train_loader

    if not opt.continue_train:
        start = 0
    else:
        start = int(opt.which_epoch)
    total_step = opt.total_step
    import datetime

    print("Start to train at %s" % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

    model.netD.feature_network.requires_grad_(False)
    step = 0
    # Training Cycle
    for epoch in range(100):
        for x_a, m_a, x_p, m_p, x_n, m_n in train_loader:

            x_a, m_a = x_a.cuda(), m_a.cuda()
            x_p, m_p = x_p.cuda(), m_p.cuda()
            x_n, m_n = x_n.cuda(), m_n.cuda()

            a_B_hid = hid_face_to_bg(netHR, x_a, m_a)

            model.netG.train()

            for interval in range(2):
                if step % 2 == 0:
                    img_id = x_p
                else:
                    img_id = x_n

                img_id_112 = F.interpolate(img_id, size=(112, 112), mode='bicubic')
                img_id_112 = img_id_112 * 2.0 - 1.0
                latent_id = model.netArc(img_id_112)
                latent_id = F.normalize(latent_id, p=2, dim=1)

                if interval:

                    img_fake = model.netG(a_B_hid, m_a, latent_id)

                    gen_logits, _ = model.netD(img_fake.detach(), None)
                    loss_Dgen = (F.relu(torch.ones_like(gen_logits) + gen_logits)).mean()

                    real_logits, _ = model.netD(x_p, None)
                    loss_Dreal = (F.relu(torch.ones_like(real_logits) - real_logits)).mean()

                    loss_D = loss_Dgen + loss_Dreal
                    optimizer_D.zero_grad()
                    loss_D.backward()
                    optimizer_D.step()
                else:

                    # model.netD.requires_grad_(True)
                    img_fake = model.netG(a_B_hid, m_a, latent_id)
                    # G loss
                    gen_logits, feat = model.netD(img_fake, None)

                    loss_Gmain = (-gen_logits).mean()
                    img_fake_down = F.interpolate(img_fake, size=(112, 112), mode='bicubic')
                    img_fake_down = img_fake_down * 2.0 - 1.0
                    latent_fake = model.netArc(img_fake_down)
                    latent_fake = F.normalize(latent_fake, p=2, dim=1)

                    loss_G_ID = (1 - model.cosin_metric(latent_fake, latent_id)).mean()
                    real_feat = model.netD.get_feature(x_a)
                    feat_match_loss = model.criterionFeat(feat["3"], real_feat["3"])
                    loss_G = loss_Gmain + loss_G_ID * opt.lambda_id + feat_match_loss * opt.lambda_feat

                    if step % 2 == 0:
                        # G_Rec
                        loss_G_Rec = model.criterionRec(img_fake, x_a) * opt.lambda_rec
                        loss_G += loss_G_Rec

                    optimizer_G.zero_grad()
                    loss_G.backward()
                    optimizer_G.step()

            ############## Display results and errors ##########
            ### print out errors
            # Print out log info
            if (step + 1) % opt.log_frep == 0:
                errors = {
                    "G_Loss": loss_Gmain.item(),
                    "G_ID": loss_G_ID.item(),
                    "G_Rec": loss_G_Rec.item(),
                    "G_feat_match": feat_match_loss.item(),
                    "D_fake": loss_Dgen.item(),
                    "D_real": loss_Dreal.item(),
                    "D_loss": loss_D.item()
                }

                message = '( step: %d, ) ' % (step)
                for k, v in errors.items():
                    message += '%s: %.3f ' % (k, v)

                print(message)
                with open(log_name, "a") as log_file:
                    log_file.write('%s\n' % message)

            ### save latest model
            if (step + 1) % opt.model_freq == 0:
                print('saving the latest model (steps %d)' % (step + 1))
                model.save(step + 1)
                np.savetxt(iter_path, (step + 1, total_step), delimiter=',', fmt='%d')

            step += 1
            if step >= total_step:
                break
