import os

import numpy as np
import dataset
from models.hrnet import HRNET, init_model
from models.loss import *
from utils.progress_bar import ProgressBar
from utils.NoiseLayer import NoiseLayer
from utils.MDSLayer import MDSLayer

if __name__ == '__main__':
    device = c.device

    netHR = HRNET()
    netHR = netHR.to(device)
    init_model(netHR)

    noise_layer = NoiseLayer()
    noise_layer = noise_layer.to(device)
    noise_layer.requires_grad_(False)

    mds_layer = MDSLayer().to(device)
    mds_layer.requires_grad_(False)
    mds_layer.eval()

    params_trainable_net = (list(filter(lambda p: p.requires_grad, netHR.parameters())))
    opt_g = torch.optim.Adam(list(netHR.parameters()), lr=c.lr_g)
    weight_scheduler_g = torch.optim.lr_scheduler.StepLR(opt_g, c.weight_step, gamma=c.gamma)

    Loss_G = HR_Loss().to(device)

    iteration = 0
    loss_history = []

    progressBar = ProgressBar()

    for i_epoch in range(c.epochs):

        for img, mask, _ in progressBar(dataset.netHR_train_loader):
            img = img.to(device)
            mask = mask.to(device)

            face = img * mask
            bg = img * (1 - mask)

            opt_g.zero_grad()

            bg_hid = netHR(mask, bg, face, rev=False)
            img_hid = bg_hid + face
            img_hid = torch.clamp(img_hid, 0.0, 1.0)
            img_hid_noised = noise_layer(img_hid)
            img_hid_noised = torch.clamp(img_hid_noised, 0.0, 1.0)

            if c.mds:
                with torch.no_grad():
                    mask_mds = mds_layer(mask)
            else:
                mask_mds = mask

            bg_hid_noised = img_hid_noised * (1 - mask_mds)

            img_rec, face_rec = netHR(mask_mds, bg_hid_noised, rev=True)

            loss_gen, all_loss = Loss_G(bg, face, bg_hid, face_rec, img, img_rec)
            loss_total = loss_gen
            loss_total.backward()
            opt_g.step()

            loss_history.append([loss_total.item(), 0.])
            iteration = iteration + 1
            weight_scheduler_g.step()

            progressBar.say(
                iter=iteration + 1,
                total=all_loss['total'],
                bg=all_loss['bg'],
                face=all_loss['face'],
                img=all_loss['img'],
                id=all_loss['id'],
            )

            if (iteration % c.SAVE_itertaion_freq == 0) & (iteration != 0):
                # 调整l2和lpips的比例
                Loss_G.set_l2_lpips_weight()

                epoch_losses = np.mean(np.array(loss_history), axis=0)
                epoch_losses[1] = np.log10(opt_g.param_groups[0]['lr'])

                print('epoch:', iteration // 1000, 'K     TOTAL_loss:', epoch_losses[0])
                loss_history = []
                netHR.save(os.path.join(c.pth_path, 'model_checkpoint_%.6i' % iteration + '.pth'))

        if iteration > c.iterations:
            break

    netHR.save(os.path.join(c.pth_path, 'fh_model_final.pth'))
