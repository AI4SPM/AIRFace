import torch.optim
import torch.nn as nn
import config as c
from models.basic_net import EhidNet, HidingFusionNet, RecoveryResUNetPP


class HRNET(nn.Module):
    def __init__(self):
        super(HRNET, self).__init__()

        self.preprocess = EhidNet()
        self.encoder = HidingFusionNet()
        self.decoder = RecoveryResUNetPP()

    def forward(self, mask, bg, face=None, rev=False):

        if not rev:  # 1bg 2 face
            face_pro = self.preprocess(face)
            out = self.encoder(torch.cat([bg, face_pro], 1))
            out_bg = out * (1 - mask)

            return out_bg

        else:
            img_rec = self.decoder(bg)
            face_rec = img_rec * mask

            return img_rec, face_rec

    def save(self, path):
        states = {
            'P': self.preprocess.state_dict(),
            'H': self.encoder.state_dict(),
            'R': self.decoder.state_dict()
        }
        torch.save(states, path)

    def load(self, path):
        states = torch.load(path, map_location=lambda storage, loc: storage)
        self.preprocess.load_state_dict(states['P'])
        self.encoder.load_state_dict(states['H'])
        self.decoder.load_state_dict(states['R'])


def init_model(mod):
    for key, param in mod.named_parameters():
        split = key.split('.')
        if param.requires_grad:
            param.data = c.init_scale * torch.randn(param.data.shape).cuda()
            if split[-2] == 'conv5':
                param.data.fill_(0.)
