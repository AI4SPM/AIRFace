import torch.nn as nn
import torch.nn.functional as F


class FeatureConverter(nn.Module):
    def __init__(self):
        super(FeatureConverter, self).__init__()
        self.fc1 = nn.Linear(512, 1024)
        self.bn1 = nn.LayerNorm(1024)
        self.fc2 = nn.Linear(1024, 512)
        self.bn2 = nn.LayerNorm(512)
        self.activation = nn.LeakyReLU(0.01)

    def forward(self, x):
        x = self.fc1(x)
        x = self.bn1(x)
        x = self.activation(x)
        x = self.fc2(x)
        x = self.bn2(x)
        x = F.normalize(x, p=2, dim=1)
        return x
