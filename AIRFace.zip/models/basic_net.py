# networks.py
import torch
import torch.nn as nn
import torch.nn.functional as F


# -------------------------
# Basic blocks
# -------------------------

def get_norm(norm: str, channels: int):
    if norm == "batch":
        return nn.BatchNorm2d(channels)
    if norm == "instance":
        return nn.InstanceNorm2d(channels, affine=True)
    if norm == "group":
        groups = 8 if channels >= 8 else 1
        return nn.GroupNorm(groups, channels)
    raise ValueError(f"Unsupported norm: {norm}")


class ResidualBlock(nn.Module):
    def __init__(self, in_ch, out_ch, norm="instance", act=nn.LeakyReLU):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            get_norm(norm, out_ch),
            act(0.2, inplace=True) if act is nn.LeakyReLU else act(inplace=True),

            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            get_norm(norm, out_ch),
        )

        if in_ch != out_ch:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, bias=False),
                get_norm(norm, out_ch),
            )
        else:
            self.shortcut = nn.Identity()

        self.out_act = act(0.2, inplace=True) if act is nn.LeakyReLU else act(inplace=True)

    def forward(self, x):
        return self.out_act(self.conv(x) + self.shortcut(x))


class DownBlock(nn.Module):
    def __init__(self, in_ch, out_ch, norm="instance"):
        super().__init__()
        self.block = nn.Sequential(
            nn.MaxPool2d(2),
            ResidualBlock(in_ch, out_ch, norm=norm),
        )

    def forward(self, x):
        return self.block(x)


class UpBlock(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch, norm="instance"):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        self.block = ResidualBlock(out_ch + skip_ch, out_ch, norm=norm)

    def forward(self, x, skip):
        x = self.up(x)

        # 保险处理，防止输入尺寸不是 2^n 倍数时出现 1 像素误差
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)

        x = torch.cat([x, skip], dim=1)
        return self.block(x)


# -------------------------
# Residual U-Net
# for Ehid and H
# -------------------------

class ResidualUNet(nn.Module):


    def __init__(
            self,
            in_channels=3,
            out_channels=3,
            base_ch=64,
            norm="instance",
            out_activation=None,
    ):
        super().__init__()

        self.enc1 = ResidualBlock(in_channels, base_ch, norm=norm)
        self.enc2 = DownBlock(base_ch, base_ch * 2, norm=norm)
        self.enc3 = DownBlock(base_ch * 2, base_ch * 4, norm=norm)
        self.enc4 = DownBlock(base_ch * 4, base_ch * 8, norm=norm)

        self.bottleneck = DownBlock(base_ch * 8, base_ch * 16, norm=norm)

        self.dec4 = UpBlock(base_ch * 16, base_ch * 8, base_ch * 8, norm=norm)
        self.dec3 = UpBlock(base_ch * 8, base_ch * 4, base_ch * 4, norm=norm)
        self.dec2 = UpBlock(base_ch * 4, base_ch * 2, base_ch * 2, norm=norm)
        self.dec1 = UpBlock(base_ch * 2, base_ch, base_ch, norm=norm)

        self.head = nn.Conv2d(base_ch, out_channels, kernel_size=1)

        if out_activation == "tanh":
            self.out_activation = nn.Tanh()
        elif out_activation == "sigmoid":
            self.out_activation = nn.Sigmoid()
        elif out_activation is None:
            self.out_activation = nn.Identity()
        else:
            raise ValueError(f"Unsupported activation: {out_activation}")

    def forward(self, x):
        e1 = self.enc1(x)  # 224
        e2 = self.enc2(e1)  # 112
        e3 = self.enc3(e2)  # 56
        e4 = self.enc4(e3)  # 28
        b = self.bottleneck(e4)  # 14

        d4 = self.dec4(b, e4)
        d3 = self.dec3(d4, e3)
        d2 = self.dec2(d3, e2)
        d1 = self.dec1(d2, e1)

        return self.out_activation(self.head(d1))


class EhidNet(nn.Module):


    def __init__(self, base_ch=64, norm="instance"):
        super().__init__()
        self.net = ResidualUNet(
            in_channels=3,
            out_channels=3,
            base_ch=base_ch,
            norm=norm,
            out_activation="tanh",
        )

    def forward(self, face):
        return self.net(face)


class HidingFusionNet(nn.Module):


    def __init__(
            self,
            base_ch=64,
            norm="instance",
            residual=True,
            strength=0.1,
    ):
        super().__init__()
        self.residual = residual
        self.strength = strength

        self.net = ResidualUNet(
            in_channels=6,
            out_channels=3,
            base_ch=base_ch,
            norm=norm,
            out_activation=None,
        )

    def forward(self, x6):

        delta = torch.tanh(self.net(x6))

        if self.residual:
            bg = x6[:, :3]
            return bg + self.strength * delta

        return delta


# -------------------------
# ResUNet++ blocks for R
# -------------------------

class SqueezeExcite(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()
        hidden = max(channels // reduction, 4)
        self.net = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, hidden, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        return x * self.net(x)


class ResConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1, norm="instance"):
        super().__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, stride=stride, padding=1, bias=False),
            get_norm(norm, out_ch),
            nn.ReLU(inplace=True),
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            get_norm(norm, out_ch),
        )

        if in_ch != out_ch or stride != 1:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride=stride, bias=False),
                get_norm(norm, out_ch),
            )
        else:
            self.shortcut = nn.Identity()

        self.se = SqueezeExcite(out_ch)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = self.conv2(self.conv1(x))
        out = out + self.shortcut(x)
        out = self.se(out)
        return self.relu(out)


class ASPP(nn.Module):
    def __init__(self, in_ch, out_ch, rates=(1, 6, 12, 18), norm="instance"):
        super().__init__()

        self.branches = nn.ModuleList()
        for r in rates:
            if r == 1:
                self.branches.append(
                    nn.Sequential(
                        nn.Conv2d(in_ch, out_ch, 1, bias=False),
                        get_norm(norm, out_ch),
                        nn.ReLU(inplace=True),
                    )
                )
            else:
                self.branches.append(
                    nn.Sequential(
                        nn.Conv2d(in_ch, out_ch, 3, padding=r, dilation=r, bias=False),
                        get_norm(norm, out_ch),
                        nn.ReLU(inplace=True),
                    )
                )

        self.project = nn.Sequential(
            nn.Conv2d(out_ch * len(rates), out_ch, 1, bias=False),
            get_norm(norm, out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        feats = [branch(x) for branch in self.branches]
        return self.project(torch.cat(feats, dim=1))


class AttentionGate(nn.Module):
    def __init__(self, skip_ch, gate_ch, inter_ch, norm="instance"):
        super().__init__()

        self.W_skip = nn.Sequential(
            nn.Conv2d(skip_ch, inter_ch, 1, bias=False),
            get_norm(norm, inter_ch),
        )

        self.W_gate = nn.Sequential(
            nn.Conv2d(gate_ch, inter_ch, 1, bias=False),
            get_norm(norm, inter_ch),
        )

        self.psi = nn.Sequential(
            nn.Conv2d(inter_ch, 1, 1),
            nn.Sigmoid(),
        )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, skip, gate):
        att = self.relu(self.W_skip(skip) + self.W_gate(gate))
        att = self.psi(att)
        return skip * att


class ResUNetPPDecoderBlock(nn.Module):
    def __init__(self, in_ch, skip_ch, out_ch, norm="instance"):
        super().__init__()

        self.up = nn.ConvTranspose2d(in_ch, out_ch, kernel_size=2, stride=2)
        self.att = AttentionGate(
            skip_ch=skip_ch,
            gate_ch=out_ch,
            inter_ch=max(out_ch // 2, 8),
            norm=norm,
        )
        self.conv = ResConvBlock(out_ch + skip_ch, out_ch, stride=1, norm=norm)

    def forward(self, x, skip):
        x = self.up(x)

        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)

        skip = self.att(skip, x)
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class RecoveryResUNetPP(nn.Module):


    def __init__(
            self,
            in_channels=3,
            out_channels=3,
            base_ch=64,
            norm="instance",
            out_activation=None,
    ):
        super().__init__()

        self.stem = ResConvBlock(in_channels, base_ch, stride=1, norm=norm)  # 224
        self.enc2 = ResConvBlock(base_ch, base_ch * 2, stride=2, norm=norm)  # 112
        self.enc3 = ResConvBlock(base_ch * 2, base_ch * 4, stride=2, norm=norm)  # 56
        self.enc4 = ResConvBlock(base_ch * 4, base_ch * 8, stride=2, norm=norm)  # 28

        self.bridge = ASPP(base_ch * 8, base_ch * 16, norm=norm)  # 28

        self.dec3 = ResUNetPPDecoderBlock(base_ch * 16, base_ch * 4, base_ch * 8, norm=norm)  # 56
        self.dec2 = ResUNetPPDecoderBlock(base_ch * 8, base_ch * 2, base_ch * 4, norm=norm)  # 112
        self.dec1 = ResUNetPPDecoderBlock(base_ch * 4, base_ch, base_ch * 2, norm=norm)  # 224

        self.final_aspp = ASPP(base_ch * 2, base_ch, rates=(1, 3, 6, 9), norm=norm)

        self.rgb_head = nn.Sequential(
            nn.Conv2d(base_ch, base_ch, kernel_size=3, padding=1, bias=False),
            get_norm(norm, base_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(base_ch, out_channels, kernel_size=1),
        )

        if out_activation == "tanh":
            self.out_activation = nn.Tanh()
        elif out_activation == "sigmoid":
            self.out_activation = nn.Sigmoid()
        elif out_activation is None:
            self.out_activation = nn.Identity()
        else:
            raise ValueError(f"Unsupported activation: {out_activation}")

    def forward(self, x):
        x1 = self.stem(x)
        x2 = self.enc2(x1)
        x3 = self.enc3(x2)
        x4 = self.enc4(x3)

        b = self.bridge(x4)

        d3 = self.dec3(b, x3)
        d2 = self.dec2(d3, x2)
        d1 = self.dec1(d2, x1)

        out = self.final_aspp(d1)
        out = self.rgb_head(out)
        return self.out_activation(out)