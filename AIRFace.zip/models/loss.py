import torch
from torch.nn import functional as F
import config as c
from torch import nn
import lpips
from torch import autograd


class HR_Loss(nn.Module):
    def __init__(self):
        super(HR_Loss, self).__init__()

        self.bg_weight = c.bg_weight
        self.face_weight = c.face_weight
        self.whole_reveal_weight = c.whole_reveal_weight
        self.id_weight = c.id_weight

        self.l2_weight = 1.0
        self.lpips_weight = 0.0

        self.netArc = torch.load(c.netArc_path, map_location=torch.device("cpu"))
        self.netArc.eval()
        self.netArc.requires_grad_(False)

        self.l2 = nn.MSELoss()

        self.lpips_loss = lpips.LPIPS(net='vgg', version='0.1')
        self.lpips_loss.eval()
        self.lpips_loss.requires_grad_(False)

    def forward(self, bg, face, bg_hid, face_rec, img, img_rec):
        bg_loss = self.l2(bg, bg_hid)

        face_loss = (self.l2_weight * self.l2(face, face_rec) +
                     self.lpips_weight * self.compute_lpips_loss(face, face_rec))
        img_rec_loss = (self.l2_weight * self.l2(img, img_rec) +
                        self.lpips_weight * self.compute_lpips_loss(img, img_rec))
        with torch.no_grad():
            orig_id = self.netArc(self.preprocess_arcface(img))
            orig_id = F.normalize(orig_id, p=2, dim=1)
        rec_id = self.netArc(self.preprocess_arcface(img_rec))
        rec_id = F.normalize(rec_id, p=2, dim=1)
        id_loss = (1 - torch.sum(orig_id * rec_id, dim=1)).mean()

        total_loss = (self.bg_weight * bg_loss +
                      self.face_weight * face_loss +
                      self.whole_reveal_weight * img_rec_loss +
                      self.id_weight * id_loss)

        return total_loss, {
            'total': total_loss.item(),
            'bg': bg_loss.item(),
            'face': face_loss.item(),
            'img': img_rec_loss.item(),
            'id': id_loss.item()
        }

    # [0,1] -> [-1,1]
    def input_range_adjust(self, img):
        img = img * 2.0 - 1.0
        return img

    def compute_lpips_loss(self, img1, img2):
        img1 = self.input_range_adjust(img1)
        img2 = self.input_range_adjust(img2)
        return self.lpips_loss(img1, img2).mean()

    def preprocess_arcface(self, img):
        img = F.interpolate(img, size=(112, 112), mode='bicubic')
        # [0,1] -> [-1,1]
        img = self.input_range_adjust(img)

        return img

    def set_l2_lpips_weight(self):
        self.l2_weight = max(0.2, self.l2_weight - 0.1)
        self.lpips_weight = min(0.8, self.lpips_weight + 0.1)
